import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';

import '../services/api_service.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  static const _apk = MethodChannel('sonic/apk_builder');
  static const _sys = MethodChannel('sonic/system');
  static const String currentVersion = '1.0.0';
  static const String _downloadPath = '/storage/emulated/0/Download/Sonic-v1.apk';

  bool _busy = false;
  bool _wake = false;

  void _snack(String m) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  /// getApkPath -> copy to Download/Sonic-v1.apk -> open installer via FileProvider.
  Future<void> _getApk() async {
    setState(() => _busy = true);
    try {
      final src = await _apk.invokeMethod<String>('getApkPath');
      String dest = _downloadPath;
      try {
        await File(src!).copy(_downloadPath); // works on older Android
      } catch (_) {
        // Android 10+ scoped storage: let native code save via MediaStore
        dest = (await _apk.invokeMethod<String>('copyApkToDownload')) ?? _downloadPath;
      }
      _snack('APK Download folder mein save ho gayi: Sonic-v1.apk');
      await _apk.invokeMethod('installApk', {'path': dest});
    } catch (e) {
      _snack('Error: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _shareApp() async {
    try {
      final src = await _apk.invokeMethod<String>('getApkPath');
      final dest = await _apk.invokeMethod<String>('copyApkToDownload');
      await Share.shareXFiles([XFile(dest ?? src!)], text: 'Sonic - Free Personal AI Assistant');
    } catch (_) {
      await Share.share('Sonic - Free Personal AI Assistant ڈاؤن لوڈ کریں!');
    }
  }

  Future<void> _checkUpdate() async {
    setState(() => _busy = true);
    try {
      final v = await ApiService().latestVersion();
      final latest = (v['version'] ?? currentVersion).toString();
      if (_isNewer(latest, currentVersion)) {
        if (!mounted) return;
        showDialog(
          context: context,
          builder: (_) => AlertDialog(
            title: Text('Naya version $latest maujood hai'),
            content: Text(v['url']?.toString() ?? ''),
            actions: [
              TextButton(onPressed: () => Navigator.pop(context), child: const Text('Baad mein')),
              if (v['url'] != null)
                FilledButton(
                  onPressed: () {
                    Clipboard.setData(ClipboardData(text: v['url'].toString()));
                    Navigator.pop(context);
                    _snack('Link copy ho gaya');
                  },
                  child: const Text('Link copy'),
                ),
            ],
          ),
        );
      } else {
        _snack('Aap latest version ($currentVersion) par hain ✅');
      }
    } catch (e) {
      _snack('Update check nahi ho saka: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  bool _isNewer(String a, String b) {
    final x = a.split('.').map((e) => int.tryParse(e) ?? 0).toList();
    final y = b.split('.').map((e) => int.tryParse(e) ?? 0).toList();
    for (var i = 0; i < 3; i++) {
      final p = i < x.length ? x[i] : 0, q = i < y.length ? y[i] : 0;
      if (p != q) return p > q;
    }
    return false;
  }

  Future<void> _toggleWake(bool on) async {
    await _sys.invokeMethod(on ? 'startWakeWord' : 'stopWakeWord');
    setState(() => _wake = on);
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        SizedBox(
          height: 80,
          child: FilledButton.icon(
            style: FilledButton.styleFrom(
              backgroundColor: cs.primary,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            ),
            onPressed: _busy ? null : _getApk,
            icon: _busy
                ? const SizedBox(width: 24, height: 24, child: CircularProgressIndicator(strokeWidth: 3))
                : const Icon(Icons.android, size: 32),
            label: const Text('BUILD / GET APK',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
          ),
        ),
        const SizedBox(height: 16),
        Card(
          child: Column(children: [
            ListTile(
              leading: const Icon(Icons.share),
              title: const Text('Share App'),
              onTap: _shareApp,
            ),
            ListTile(
              leading: const Icon(Icons.system_update),
              title: const Text('Check Update'),
              subtitle: const Text('Current: $currentVersion'),
              onTap: _busy ? null : _checkUpdate,
            ),
            SwitchListTile(
              secondary: const Icon(Icons.hearing),
              title: const Text('Wake word "Sonic"'),
              value: _wake,
              onChanged: _toggleWake,
            ),
            ListTile(
              leading: const Icon(Icons.accessibility_new),
              title: const Text('Accessibility service (phone control)'),
              onTap: () => _sys.invokeMethod('openAccessibilitySettings'),
            ),
            ListTile(
              leading: const Icon(Icons.security),
              title: const Text('Permissions dobara dekhein'),
              onTap: () => Navigator.pushNamed(context, '/permissions'),
            ),
          ]),
        ),
      ]),
    );
  }
}
