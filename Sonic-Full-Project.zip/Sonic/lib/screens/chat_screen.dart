import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;

import '../services/api_service.dart';
import '../services/memory_service.dart';
import '../utils/limit_manager.dart';

class Msg {
  final String text;
  final bool user;
  final Uint8List? imageBytes;
  final String? imageUrl;
  Msg(this.text, this.user, {this.imageBytes, this.imageUrl});
}

bool isUrdu(String s) => RegExp(r'[\u0600-\u06FF]').hasMatch(s);

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});
  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _ctrl = TextEditingController();
  final _scroll = ScrollController();
  final _stt = stt.SpeechToText();
  final _tts = FlutterTts();
  final _limit = LimitManager();
  final _api = ApiService();
  final _mem = MemoryService();

  final List<Msg> _msgs = [];
  bool _listening = false, _busy = false, _sttReady = false;
  String _locale = 'ur_PK';
  String _imageLabel = 'Images: 0/${LimitManager.dailyLimit}';

  static const _stopPhrases = [
    'chup ho jao', 'chup ho ja', 'chup', 'stop', 'khamosh', 'ruk jao',
    'خاموش', 'چپ ہو جاؤ', 'چپ', 'رک جاؤ', 'بس'
  ];

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    _sttReady = await _stt.initialize(onError: (_) => setState(() => _listening = false));
    await _refreshLimit();
    await _dailyGreeting();
  }

  Future<void> _refreshLimit() async {
    final l = await _limit.label();
    if (mounted) setState(() => _imageLabel = l);
  }

  String _greetingText() {
    final name = _mem.name;
    final h = DateTime.now().hour;
    final who = name != null ? ' $name' : '';
    if (h < 12) return 'صبح بخیر$who! ☀️ آج کا دن بہت شاندار ہوگا۔ بتائیں، میں آپ کی کیا مدد کروں؟';
    if (h < 17) return 'السلام علیکم$who! 😊 کیسا گزر رہا ہے دن؟';
    return 'شام بخیر$who! 🌙 آج کیسا رہا دن؟ مجھے سب بتائیں۔';
  }

  /// Daily 9 AM greeting: shown the first time the app opens at/after 9 AM each day.
  Future<void> _dailyGreeting() async {
    final p = await SharedPreferences.getInstance();
    final now = DateTime.now();
    final today = '${now.year}-${now.month}-${now.day}';
    final first = !_msgs.any((m) => !m.user);
    if (first && (p.getString('last_greet') != today) && now.hour >= 9) {
      await p.setString('last_greet', today);
      _addBot('${_greetingText()}\n\n(Sonic aapka dost, hamesha free 💜)');
    } else if (first) {
      _addBot('السلام علیکم! میں Sonic ہوں۔ بات کریں یا مائیک دبائیں 🎙️');
    }
  }

  void _addBot(String t, {Uint8List? bytes, String? url}) {
    setState(() => _msgs.add(Msg(t, false, imageBytes: bytes, imageUrl: url)));
    _scrollDown();
  }

  void _scrollDown() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) {
        _scroll.animateTo(_scroll.position.maxScrollExtent + 120,
            duration: const Duration(milliseconds: 250), curve: Curves.easeOut);
      }
    });
  }

  bool _isStopCommand(String t) {
    final s = t.trim().toLowerCase();
    if (s.split(RegExp(r'\s+')).length > 4) return false;
    return _stopPhrases.any((p) => s == p || s.contains(p));
  }

  Future<void> _speak(String text) async {
    await _tts.setLanguage(isUrdu(text) ? 'ur-PK' : 'en-US');
    await _tts.speak(text);
  }

  bool _isImageRequest(String t) =>
      RegExp(r'^(/image|image|tasveer|tasweer|تصویر)\b', caseSensitive: false).hasMatch(t.trim());

  Future<void> _send([String? voiceText]) async {
    final text = (voiceText ?? _ctrl.text).trim();
    if (text.isEmpty) return;
    _ctrl.clear();

    if (_isStopCommand(text)) {
      await _tts.stop();
      return;
    }

    setState(() {
      _msgs.add(Msg(text, true));
      _busy = true;
    });
    _scrollDown();
    _mem.learn(text);

    if (_isImageRequest(text)) {
      await _generateImage(text.replaceFirst(RegExp(r'^(/image|image|tasveer|tasweer|تصویر)\s*', caseSensitive: false), ''));
    } else {
      final history = _msgs
          .where((m) => m.imageBytes == null && m.imageUrl == null)
          .toList()
          .reversed
          .take(10)
          .toList()
          .reversed
          .map((m) => {'role': m.user ? 'user' : 'assistant', 'content': m.text})
          .toList();
      final reply = await _api.chat(text, history: history, user: _mem.profile);
      _addBot(reply);
      _speak(reply);
    }
    if (mounted) setState(() => _busy = false);
  }

  Future<void> _generateImage(String prompt) async {
    if (prompt.isEmpty) {
      _addBot('کس چیز کی تصویر بناؤں؟ مثال: "image ایک خوبصورت پہاڑ"');
      return;
    }
    if (!await _limit.canGenerate()) {
      _addBot(LimitManager.limitMessage);
      return;
    }
    try {
      final r = await _api.generateImage(prompt);
      await _limit.increment();
      await _refreshLimit();
      _addBot('لیجیے، آپ کی تصویر تیار ہے 🎨', bytes: r.bytes, url: r.url);
    } catch (e) {
      _addBot('تصویر نہیں بن سکی: $e');
    }
  }

  Future<void> _toggleMic() async {
    if (!_sttReady) return;
    if (_listening) {
      await _stt.stop();
      setState(() => _listening = false);
      return;
    }
    await _tts.stop();
    setState(() => _listening = true);
    await _stt.listen(
      localeId: _locale,
      onResult: (r) {
        _ctrl.text = r.recognizedWords;
        if (r.finalResult) {
          setState(() => _listening = false);
          _send(r.recognizedWords);
        } else if (_isStopCommand(r.recognizedWords)) {
          _tts.stop(); // instant stop while Sonic is talking
        }
      },
    );
  }

  @override
  void dispose() {
    _tts.stop();
    _stt.stop();
    super.dispose();
  }

  Widget _bubble(Msg m) {
    final cs = Theme.of(context).colorScheme;
    final rtl = isUrdu(m.text);
    return Align(
      alignment: m.user ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.82),
        margin: const EdgeInsets.symmetric(vertical: 4, horizontal: 10),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: m.user ? cs.primaryContainer : cs.surfaceContainerHighest,
          borderRadius: BorderRadius.circular(16),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          if (m.imageBytes != null) ClipRRect(borderRadius: BorderRadius.circular(12), child: Image.memory(m.imageBytes!)),
          if (m.imageUrl != null) ClipRRect(borderRadius: BorderRadius.circular(12), child: Image.network(m.imageUrl!)),
          Directionality(
            textDirection: rtl ? TextDirection.rtl : TextDirection.ltr,
            child: SizedBox(
              width: double.infinity,
              child: SelectableText(m.text, style: const TextStyle(fontSize: 16, height: 1.4)),
            ),
          ),
          if (!m.user)
            Row(mainAxisSize: MainAxisSize.min, children: [
              IconButton(
                visualDensity: VisualDensity.compact,
                icon: const Icon(Icons.copy, size: 18),
                onPressed: () {
                  Clipboard.setData(ClipboardData(text: m.text));
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Copy ho gaya')));
                },
              ),
              IconButton(
                visualDensity: VisualDensity.compact,
                icon: const Icon(Icons.share, size: 18),
                onPressed: () => Share.share(m.text),
              ),
              IconButton(
                visualDensity: VisualDensity.compact,
                icon: const Icon(Icons.volume_up, size: 18),
                onPressed: () => _speak(m.text),
              ),
            ]),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Sonic'),
        actions: [
          Center(
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.secondaryContainer,
                  borderRadius: BorderRadius.circular(12)),
              child: Text(_imageLabel, style: const TextStyle(fontWeight: FontWeight.bold)),
            ),
          ),
          IconButton(
            tooltip: 'Zuban',
            icon: Text(_locale == 'ur_PK' ? 'اردو' : 'EN', style: const TextStyle(fontWeight: FontWeight.bold)),
            onPressed: () => setState(() => _locale = _locale == 'ur_PK' ? 'en_US' : 'ur_PK'),
          ),
          PopupMenuButton<String>(
            onSelected: (v) async {
              await Navigator.pushNamed(context, v);
              _refreshLimit();
            },
            itemBuilder: (_) => const [
              PopupMenuItem(value: '/image', child: Text('Tasveer banayen')),
              PopupMenuItem(value: '/video', child: Text('Video edit')),
              PopupMenuItem(value: '/youtube', child: Text('YouTube assistant')),
              PopupMenuItem(value: '/settings', child: Text('Settings')),
            ],
          ),
        ],
      ),
      body: Column(children: [
        Expanded(
          child: ListView.builder(
            controller: _scroll,
            padding: const EdgeInsets.symmetric(vertical: 8),
            itemCount: _msgs.length,
            itemBuilder: (_, i) => _bubble(_msgs[i]),
          ),
        ),
        if (_busy) const LinearProgressIndicator(),
        SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(8, 4, 8, 8),
            child: Row(children: [
              IconButton.filledTonal(
                onPressed: _toggleMic,
                icon: Icon(_listening ? Icons.stop : Icons.mic),
              ),
              const SizedBox(width: 6),
              Expanded(
                child: TextField(
                  controller: _ctrl,
                  minLines: 1,
                  maxLines: 4,
                  textInputAction: TextInputAction.send,
                  onSubmitted: (_) => _send(),
                  onChanged: (v) => setState(() {}),
                  textDirection: isUrdu(_ctrl.text) ? TextDirection.rtl : TextDirection.ltr,
                  decoration: InputDecoration(
                    hintText: 'کچھ لکھیں یا بولیں...',
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(24)),
                    contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                  ),
                ),
              ),
              const SizedBox(width: 6),
              IconButton.filled(onPressed: _busy ? null : () => _send(), icon: const Icon(Icons.send)),
            ]),
          ),
        ),
      ]),
    );
  }
}
