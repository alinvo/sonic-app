import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});
  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final _ctrl = PageController();
  int _page = 0;

  static const _pages = [
    ('🎙️', 'Sonic mein khush aamdeed!', 'Aapka muft, pyaara aur mazaakiya AI dost. Hamesha ke liye FREE.'),
    ('🗣️', 'Bolein, Sonic sunega', 'Urdu ya English mein baat karein. "Sonic" kehkar jagayen.'),
    ('📱', 'Phone aapke hukm par', 'Call, SMS, app kholna — sab Sonic kar dega. Roz 4 tasveerein bhi banayen.'),
  ];

  Future<void> _finish() async {
    final p = await SharedPreferences.getInstance();
    await p.setBool('onboarded', true);
    if (mounted) Navigator.pushReplacementNamed(context, '/permissions');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(children: [
          Expanded(
            child: PageView.builder(
              controller: _ctrl,
              itemCount: _pages.length,
              onPageChanged: (i) => setState(() => _page = i),
              itemBuilder: (_, i) => Padding(
                padding: const EdgeInsets.all(32),
                child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Text(_pages[i].$1, style: const TextStyle(fontSize: 96)),
                  const SizedBox(height: 24),
                  Text(_pages[i].$2,
                      textAlign: TextAlign.center,
                      style: Theme.of(context).textTheme.headlineMedium),
                  const SizedBox(height: 12),
                  Text(_pages[i].$3,
                      textAlign: TextAlign.center,
                      style: Theme.of(context).textTheme.bodyLarge),
                ]),
              ),
            ),
          ),
          Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            for (int i = 0; i < _pages.length; i++)
              Container(
                margin: const EdgeInsets.all(4),
                width: i == _page ? 20 : 8,
                height: 8,
                decoration: BoxDecoration(
                    color: i == _page ? Theme.of(context).colorScheme.primary : Colors.grey,
                    borderRadius: BorderRadius.circular(4)),
              ),
          ]),
          Padding(
            padding: const EdgeInsets.all(24),
            child: SizedBox(
              width: double.infinity,
              height: 52,
              child: FilledButton(
                onPressed: () {
                  if (_page == _pages.length - 1) {
                    _finish();
                  } else {
                    _ctrl.nextPage(duration: const Duration(milliseconds: 300), curve: Curves.easeOut);
                  }
                },
                child: Text(_page == _pages.length - 1 ? 'Shuru karein' : 'Aage'),
              ),
            ),
          ),
        ]),
      ),
    );
  }
}
