import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:googleapis/youtube/v3.dart' as yt;
import 'package:http/http.dart' as http;

import '../services/api_service.dart';

/// Adds Google auth headers to every request (no extra package needed).
class _GoogleAuthClient extends http.BaseClient {
  final Map<String, String> _headers;
  final http.Client _inner = http.Client();
  _GoogleAuthClient(this._headers);
  @override
  Future<http.StreamedResponse> send(http.BaseRequest request) =>
      _inner.send(request..headers.addAll(_headers));
}

class YoutubeAssistantScreen extends StatefulWidget {
  const YoutubeAssistantScreen({super.key});
  @override
  State<YoutubeAssistantScreen> createState() => _YoutubeAssistantScreenState();
}

class _YoutubeAssistantScreenState extends State<YoutubeAssistantScreen> {
  final _api = ApiService();
  final _topic = TextEditingController();
  final _script = TextEditingController();
  final _title = TextEditingController();
  final _desc = TextEditingController();
  final _tags = TextEditingController();
  final _gsi = GoogleSignIn(scopes: [yt.YouTubeApi.youtubeUploadScope]);

  int _step = 0;
  bool _busy = false;
  String? _videoPath;
  String _log = '';

  Future<void> _makeScript() async {
    setState(() => _busy = true);
    final r = await _api.chat('Write a short engaging YouTube video script (hook, 3 points, call-to-action) on the topic: ${_topic.text}');
    _script.text = r;
    setState(() {
      _busy = false;
      _step = 1;
    });
  }

  Future<void> _makeMeta() async {
    setState(() => _busy = true);
    final r = await _api.chat(
        'For this YouTube script, give exactly 3 lines: line1 = catchy title, line2 = description (2 sentences), line3 = 10 comma-separated tags. Script:\n${_script.text}');
    final lines = r.split('\n').where((l) => l.trim().isNotEmpty).toList();
    _title.text = lines.isNotEmpty ? lines[0].replaceAll(RegExp(r'^\w*\s*[:\-]\s*'), '') : _topic.text;
    _desc.text = lines.length > 1 ? lines[1] : '';
    _tags.text = lines.length > 2 ? lines[2] : '';
    setState(() {
      _busy = false;
      _step = 2;
    });
  }

  Future<void> _pickVideo() async {
    final r = await FilePicker.platform.pickFiles(type: FileType.video);
    if (r?.files.single.path != null) setState(() => _videoPath = r!.files.single.path);
  }

  Future<void> _upload() async {
    if (_videoPath == null) return;
    setState(() {
      _busy = true;
      _log = 'Google sign-in...';
    });
    try {
      final user = await _gsi.signIn();
      if (user == null) throw Exception('Sign-in cancel');
      final client = _GoogleAuthClient(await user.authHeaders);
      final api = yt.YouTubeApi(client);
      final file = File(_videoPath!);
      final video = yt.Video(
        snippet: yt.VideoSnippet(
          title: _title.text,
          description: _desc.text,
          tags: _tags.text.split(',').map((e) => e.trim()).where((e) => e.isNotEmpty).toList(),
        ),
        status: yt.VideoStatus(privacyStatus: 'unlisted'),
      );
      setState(() => _log = 'Upload ho rahi hai (Unlisted)...');
      final res = await api.videos.insert(
        video,
        ['snippet', 'status'],
        uploadMedia: yt.Media(file.openRead(), await file.length()),
      );
      setState(() => _log = 'Upload mukammal ✅  https://youtu.be/${res.id}');
    } catch (e) {
      setState(() => _log = 'Error: $e');
    } finally {
      setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('YouTube assistant')),
      body: Stepper(
        currentStep: _step,
        controlsBuilder: (_, __) => const SizedBox.shrink(),
        steps: [
          Step(
            title: const Text('Topic'),
            isActive: _step >= 0,
            content: Column(children: [
              TextField(controller: _topic, decoration: const InputDecoration(hintText: 'Video ka topic')),
              const SizedBox(height: 8),
              FilledButton(onPressed: _busy ? null : _makeScript, child: const Text('Script banayen')),
            ]),
          ),
          Step(
            title: const Text('Script'),
            isActive: _step >= 1,
            content: Column(children: [
              TextField(controller: _script, maxLines: 8, decoration: const InputDecoration(border: OutlineInputBorder())),
              const SizedBox(height: 8),
              FilledButton(onPressed: _busy ? null : _makeMeta, child: const Text('Metadata banayen')),
            ]),
          ),
          Step(
            title: const Text('Metadata'),
            isActive: _step >= 2,
            content: Column(children: [
              TextField(controller: _title, decoration: const InputDecoration(labelText: 'Title')),
              TextField(controller: _desc, maxLines: 3, decoration: const InputDecoration(labelText: 'Description')),
              TextField(controller: _tags, decoration: const InputDecoration(labelText: 'Tags')),
              const SizedBox(height: 8),
              FilledButton(onPressed: () => setState(() => _step = 3), child: const Text('Aage')),
            ]),
          ),
          Step(
            title: const Text('Upload (Unlisted)'),
            isActive: _step >= 3,
            content: Column(children: [
              OutlinedButton.icon(onPressed: _pickVideo, icon: const Icon(Icons.video_file), label: Text(_videoPath == null ? 'Video chunein' : _videoPath!.split('/').last)),
              const SizedBox(height: 8),
              FilledButton.icon(onPressed: _busy ? null : _upload, icon: const Icon(Icons.upload), label: const Text('Upload karein')),
              if (_busy) const Padding(padding: EdgeInsets.all(8), child: LinearProgressIndicator()),
              Text(_log),
            ]),
          ),
        ],
      ),
    );
  }
}
