import 'dart:io';
import 'package:ffmpeg_kit_flutter/ffmpeg_kit.dart';
import 'package:ffmpeg_kit_flutter/return_code.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

/// Video edit placeholder: pick a video, trim the first N seconds, share the result.
class VideoEditScreen extends StatefulWidget {
  const VideoEditScreen({super.key});
  @override
  State<VideoEditScreen> createState() => _VideoEditScreenState();
}

class _VideoEditScreenState extends State<VideoEditScreen> {
  String? _input, _output;
  double _seconds = 10;
  bool _busy = false;
  String _status = 'Video chunein';

  Future<void> _pick() async {
    final r = await FilePicker.platform.pickFiles(type: FileType.video);
    if (r?.files.single.path != null) {
      setState(() {
        _input = r!.files.single.path;
        _output = null;
        _status = 'Chuni gayi: ${_input!.split('/').last}';
      });
    }
  }

  Future<void> _trim() async {
    if (_input == null) return;
    setState(() {
      _busy = true;
      _status = 'Process ho rahi hai...';
    });
    final dir = await getTemporaryDirectory();
    final out = '${dir.path}/sonic_trim_${DateTime.now().millisecondsSinceEpoch}.mp4';
    final session = await FFmpegKit.execute('-y -i "$_input" -t ${_seconds.round()} -c:v libx264 -preset veryfast -c:a aac "$out"');
    final rc = await session.getReturnCode();
    setState(() {
      _busy = false;
      if (ReturnCode.isSuccess(rc) && File(out).existsSync()) {
        _output = out;
        _status = 'Tayyar! ✅';
      } else {
        _status = 'FFmpeg error';
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Video edit')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Text(_status, textAlign: TextAlign.center),
          const SizedBox(height: 12),
          OutlinedButton.icon(onPressed: _pick, icon: const Icon(Icons.video_file), label: const Text('Video chunein')),
          const SizedBox(height: 12),
          Text('Pehle ${_seconds.round()} second rakhein'),
          Slider(value: _seconds, min: 1, max: 60, divisions: 59, onChanged: (v) => setState(() => _seconds = v)),
          FilledButton.icon(
              onPressed: (_input == null || _busy) ? null : _trim,
              icon: const Icon(Icons.content_cut),
              label: const Text('Trim')),
          if (_busy) const Padding(padding: EdgeInsets.all(16), child: LinearProgressIndicator()),
          if (_output != null)
            FilledButton.tonalIcon(
                onPressed: () => Share.shareXFiles([XFile(_output!)]),
                icon: const Icon(Icons.share),
                label: const Text('Share')),
        ]),
      ),
    );
  }
}
