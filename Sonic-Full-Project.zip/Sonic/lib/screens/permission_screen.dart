import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';

class _Perm {
  final String title;
  final String reason; // Urdu reason
  final IconData icon;
  final Permission? permission; // null => accessibility (special)
  const _Perm(this.title, this.reason, this.icon, this.permission);
}

class PermissionScreen extends StatefulWidget {
  const PermissionScreen({super.key});
  @override
  State<PermissionScreen> createState() => _PermissionScreenState();
}

class _PermissionScreenState extends State<PermissionScreen> {
  static const _sys = MethodChannel('sonic/system');

  final List<_Perm> _perms = [
    _Perm('مائیکروفون', 'تاکہ میں آپ کی آواز سن سکوں اور آپ سے بات کر سکوں۔', Icons.mic, Permission.microphone),
    _Perm('نوٹیفکیشن', 'تاکہ میں آپ کو یاد دہانی اور صبح کی سلام بھیج سکوں۔', Icons.notifications, Permission.notification),
    _Perm('دوسری ایپس کے اوپر دکھانا', 'تاکہ ایمرجنسی "STOP" بٹن ہر ایپ کے اوپر نظر آئے۔', Icons.layers, Permission.systemAlertWindow),
    _Perm('رابطے (Contacts)', 'تاکہ آپ کہیں "امی کو فون کرو" اور میں نمبر ڈھونڈ لوں۔', Icons.contacts, Permission.contacts),
    _Perm('فون کال', 'تاکہ میں آپ کے حکم پر کال ملا سکوں۔', Icons.call, Permission.phone),
    _Perm('ایس ایم ایس', 'تاکہ میں آپ کے لیے پیغام بھیج سکوں۔', Icons.sms, Permission.sms),
    _Perm('تصاویر', 'تاکہ میں آپ کی گیلری کی تصاویر اور ویڈیوز استعمال کر سکوں۔', Icons.photo_library, Permission.photos),
    _Perm('کیمرہ', 'تاکہ میں تصویر کھینچنے اور دیکھنے میں مدد کر سکوں۔', Icons.camera_alt, Permission.camera),
    _Perm('مقام (Location)', 'تاکہ موسم اور آس پاس کی جگہیں بتا سکوں۔', Icons.location_on, Permission.locationWhenInUse),
    _Perm('بیٹری آپٹیمائزیشن', 'تاکہ "Sonic" کہنے پر میں پس منظر میں بھی جاگتا رہوں۔', Icons.battery_charging_full, Permission.ignoreBatteryOptimizations),
    _Perm('ایکسیسبیلیٹی سروس', 'تاکہ میں ٹیپ، ٹائپ اور ایپس کھولنے جیسے کام آپ کے لیے کر سکوں۔', Icons.accessibility_new, null),
  ];

  int _index = 0;
  final Map<int, bool> _granted = {};

  Future<void> _ask() async {
    final p = _perms[_index];
    bool ok;
    if (p.permission == null) {
      await _sys.invokeMethod('openAccessibilitySettings');
      ok = false; // user toggles it manually; verified when they return
    } else {
      final status = await p.permission!.request();
      ok = status.isGranted;
      if (status.isPermanentlyDenied && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Settings mein ja kar yeh permission on karein'),
        ));
        await openAppSettings();
      }
    }
    _granted[_index] = ok;
    if (p.permission != null) _next();
  }

  Future<void> _next() async {
    if (_index < _perms.length - 1) {
      setState(() => _index++);
    } else {
      await _finish();
    }
  }

  Future<void> _finish() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('perms_done', true);
    try {
      await _sys.invokeMethod('startWakeWord');
    } catch (_) {}
    if (mounted) Navigator.pushReplacementNamed(context, '/chat');
  }

  @override
  Widget build(BuildContext context) {
    final p = _perms[_index];
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: const Text('Permissions'), automaticallyImplyLeading: false),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(children: [
          LinearProgressIndicator(value: (_index + 1) / _perms.length),
          const SizedBox(height: 8),
          Text('${_index + 1} / ${_perms.length}'),
          const Spacer(),
          CircleAvatar(
            radius: 56,
            backgroundColor: cs.primaryContainer,
            child: Icon(p.icon, size: 56, color: cs.onPrimaryContainer),
          ),
          const SizedBox(height: 24),
          Directionality(
            textDirection: TextDirection.rtl,
            child: Column(children: [
              Text(p.title, style: Theme.of(context).textTheme.headlineSmall, textAlign: TextAlign.center),
              const SizedBox(height: 12),
              Text(p.reason, style: Theme.of(context).textTheme.bodyLarge, textAlign: TextAlign.center),
            ]),
          ),
          const Spacer(),
          SizedBox(
            width: double.infinity,
            height: 52,
            child: FilledButton.icon(
              onPressed: _ask,
              icon: const Icon(Icons.check),
              label: Text(p.permission == null ? 'Settings kholein' : 'Ijazat dein'),
            ),
          ),
          const SizedBox(height: 8),
          TextButton(onPressed: _next, child: Text(p.permission == null ? 'Ho gaya / Chhorein' : 'Abhi nahi')),
        ]),
      ),
    );
  }
}
