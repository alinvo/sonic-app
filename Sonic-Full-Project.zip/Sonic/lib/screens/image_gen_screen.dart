import 'dart:typed_data';
import 'package:flutter/material.dart';
import '../services/api_service.dart';
import '../utils/limit_manager.dart';

class ImageGenScreen extends StatefulWidget {
  const ImageGenScreen({super.key});
  @override
  State<ImageGenScreen> createState() => _ImageGenScreenState();
}

class _ImageGenScreenState extends State<ImageGenScreen> {
  final _prompt = TextEditingController();
  final _limit = LimitManager();
  final _api = ApiService();
  Uint8List? _bytes;
  String? _url;
  bool _busy = false;
  String _label = 'Images: 0/${LimitManager.dailyLimit}';

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  Future<void> _refresh() async {
    final l = await _limit.label();
    if (mounted) setState(() => _label = l);
  }

  Future<void> _generate() async {
    final p = _prompt.text.trim();
    if (p.isEmpty) return;
    if (!await _limit.canGenerate()) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text(LimitManager.limitMessage)));
      return;
    }
    setState(() => _busy = true);
    try {
      final r = await _api.generateImage(p);
      await _limit.increment();
      setState(() {
        _bytes = r.bytes;
        _url = r.url;
      });
      await _refresh();
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: $e')));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Tasveer banayen'), actions: [
        Center(child: Padding(padding: const EdgeInsets.only(right: 16), child: Text(_label))),
      ]),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(children: [
          TextField(
            controller: _prompt,
            maxLines: 3,
            decoration: const InputDecoration(
                border: OutlineInputBorder(), hintText: 'Kaisi tasveer chahiye? / کیسی تصویر چاہیے؟'),
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            height: 48,
            child: FilledButton.icon(
                onPressed: _busy ? null : _generate,
                icon: const Icon(Icons.auto_awesome),
                label: const Text('Generate')),
          ),
          const SizedBox(height: 16),
          Expanded(
            child: Center(
              child: _busy
                  ? const CircularProgressIndicator()
                  : _bytes != null
                      ? Image.memory(_bytes!)
                      : _url != null
                          ? Image.network(_url!)
                          : const Text('Yahan tasveer nazar aayegi'),
            ),
          ),
        ]),
      ),
    );
  }
}
