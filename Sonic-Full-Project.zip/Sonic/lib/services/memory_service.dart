import 'package:hive/hive.dart';

/// Remembers the user's name and city in Hive.
class MemoryService {
  Box get _box => Hive.box('memory');

  String? get name => _box.get('name') as String?;
  String? get city => _box.get('city') as String?;

  /// Very small heuristic parser for "mera naam X hai", "my name is X", "main X se hoon", "I live in X".
  void learn(String text) {
    final t = text.trim();
    final name = RegExp(r'(?:mera naam|my name is|main hoon|میرا نام)\s+([^\s,.]+)', caseSensitive: false).firstMatch(t);
    if (name != null) _box.put('name', name.group(1));
    final city = RegExp(r'(?:main|i live in|i am from|میں)\s+([^\s,.]+)\s+(?:se hoon|mein rehta|mein rehti|سے ہوں|میں رہتا)', caseSensitive: false).firstMatch(t) ??
        RegExp(r'(?:i live in|i am from)\s+([^\s,.]+)', caseSensitive: false).firstMatch(t);
    if (city != null) _box.put('city', city.group(1));
  }

  Map<String, String?> get profile => {'name': name, 'city': city};
}
