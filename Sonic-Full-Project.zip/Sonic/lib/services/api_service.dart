import 'dart:convert';
import 'dart:typed_data';
import 'package:http/http.dart' as http;

/// All AI calls go through YOUR backend proxy. No API keys in the app.
class ApiService {
  static const String baseUrl = 'https://api.example.com';
  static const Duration _timeout = Duration(seconds: 60);

  static const String systemPersonality =
      'You are Sonic, a warm, caring, funny personal AI assistant. Be about 70% emotional and '
      'friendly, add light humour, and reply in the same language the user writes in '
      '(Urdu script for Urdu, English for English). Keep answers clear and short.';

  /// POST /chat  body: {message, history, personality, user}  ->  {reply}
  Future<String> chat(String message,
      {List<Map<String, String>> history = const [], Map<String, String?>? user}) async {
    try {
      final res = await http
          .post(Uri.parse('$baseUrl/chat'),
              headers: {'Content-Type': 'application/json'},
              body: jsonEncode({
                'message': message,
                'history': history,
                'personality': systemPersonality,
                'user': user ?? {},
              }))
          .timeout(_timeout);
      if (res.statusCode != 200) throw Exception('Server ${res.statusCode}');
      final data = jsonDecode(utf8.decode(res.bodyBytes));
      return (data['reply'] ?? data['message'] ?? '').toString();
    } catch (e) {
      return 'Maaf kijiye, abhi server se rabta nahi ho saka. Thori der baad try karein. ($e)';
    }
  }

  /// POST /api/image  body: {prompt} -> {image_base64} or {url}
  Future<ImageResult> generateImage(String prompt) async {
    final res = await http
        .post(Uri.parse('$baseUrl/api/image'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({'prompt': prompt}))
        .timeout(const Duration(seconds: 120));
    if (res.statusCode != 200) throw Exception('Server ${res.statusCode}');
    final data = jsonDecode(utf8.decode(res.bodyBytes));
    if (data['image_base64'] != null) {
      return ImageResult(bytes: base64Decode(data['image_base64']));
    }
    if (data['url'] != null) return ImageResult(url: data['url']);
    throw Exception('Tasveer nahi mili');
  }

  /// GET /api/version -> {version, url}
  Future<Map<String, dynamic>> latestVersion() async {
    final res = await http.get(Uri.parse('$baseUrl/api/version')).timeout(const Duration(seconds: 20));
    if (res.statusCode != 200) throw Exception('Server ${res.statusCode}');
    return jsonDecode(res.body) as Map<String, dynamic>;
  }
}

class ImageResult {
  final Uint8List? bytes;
  final String? url;
  ImageResult({this.bytes, this.url});
}
