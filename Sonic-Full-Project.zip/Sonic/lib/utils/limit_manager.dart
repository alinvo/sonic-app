import 'package:shared_preferences/shared_preferences.dart';

/// Daily image limit: 4 per day, resets at local midnight (12 AM).
class LimitManager {
  static const int dailyLimit = 4;
  static const String _kDate = 'last_image_date';
  static const String _kCount = 'image_count';
  static const String limitMessage =
      'Aaj ki 4 tasveeron ki limit khatam, kal 12 baje reset hogi';

  String _today() {
    final n = DateTime.now();
    return '${n.year}-${n.month.toString().padLeft(2, '0')}-${n.day.toString().padLeft(2, '0')}';
  }

  /// Resets the counter if the stored date is not today. Returns the current count.
  Future<int> resetCheck() async {
    final p = await SharedPreferences.getInstance();
    if (p.getString(_kDate) != _today()) {
      await p.setString(_kDate, _today());
      await p.setInt(_kCount, 0);
      return 0;
    }
    return p.getInt(_kCount) ?? 0;
  }

  Future<bool> canGenerate() async => (await resetCheck()) < dailyLimit;

  Future<int> increment() async {
    final p = await SharedPreferences.getInstance();
    final c = (await resetCheck()) + 1;
    await p.setInt(_kCount, c);
    return c;
  }

  Future<int> count() => resetCheck();

  Future<String> label() async => 'Images: ${await resetCheck()}/$dailyLimit';
}
