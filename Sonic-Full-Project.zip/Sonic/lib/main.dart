import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'screens/chat_screen.dart';
import 'screens/image_gen_screen.dart';
import 'screens/onboarding_screen.dart';
import 'screens/permission_screen.dart';
import 'screens/settings_screen.dart';
import 'screens/video_edit_screen.dart';
import 'screens/youtube_assistant_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final dir = await getApplicationDocumentsDirectory();
  Hive.init(dir.path);
  await Hive.openBox('memory');
  final prefs = await SharedPreferences.getInstance();
  final start = !(prefs.getBool('onboarded') ?? false)
      ? '/onboarding'
      : !(prefs.getBool('perms_done') ?? false)
          ? '/permissions'
          : '/chat';
  runApp(SonicApp(initialRoute: start));
}

class SonicApp extends StatelessWidget {
  final String initialRoute;
  const SonicApp({super.key, required this.initialRoute});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Sonic',
      debugShowCheckedModeBanner: false,
      themeMode: ThemeMode.dark,
      darkTheme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        colorScheme: ColorScheme.fromSeed(
            seedColor: const Color(0xFF7C4DFF), brightness: Brightness.dark),
      ),
      theme: ThemeData(useMaterial3: true),
      initialRoute: initialRoute,
      routes: {
        '/onboarding': (_) => const OnboardingScreen(),
        '/permissions': (_) => const PermissionScreen(),
        '/chat': (_) => const ChatScreen(),
        '/settings': (_) => const SettingsScreen(),
        '/image': (_) => const ImageGenScreen(),
        '/video': (_) => const VideoEditScreen(),
        '/youtube': (_) => const YoutubeAssistantScreen(),
      },
    );
  }
}
