package com.sonic.assistant

import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.Settings
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.io.File

class MainActivity : FlutterActivity() {

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        val messenger = flutterEngine.dartExecutor.binaryMessenger

        // ---------- APK builder channel ----------
        MethodChannel(messenger, "sonic/apk_builder").setMethodCallHandler { call, result ->
            try {
                when (call.method) {
                    "getApkPath" -> result.success(applicationInfo.sourceDir)
                    "copyApkToDownload" -> result.success(copyApkToDownload())
                    "installApk" -> {
                        val path = call.argument<String>("path") ?: copyApkToDownload()
                        installApk(path)
                        result.success(true)
                    }
                    else -> result.notImplemented()
                }
            } catch (e: Exception) {
                result.error("APK_ERROR", e.message, null)
            }
        }

        // ---------- System / services channel ----------
        MethodChannel(messenger, "sonic/system").setMethodCallHandler { call, result ->
            when (call.method) {
                "openAccessibilitySettings" -> {
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    result.success(true)
                }
                "isAccessibilityEnabled" -> result.success(AssistantAccessibilityService.instance != null)
                "startWakeWord" -> {
                    ContextCompat.startForegroundService(this, Intent(this, WakeWordService::class.java))
                    result.success(true)
                }
                "stopWakeWord" -> {
                    stopService(Intent(this, WakeWordService::class.java))
                    result.success(true)
                }
                else -> result.notImplemented()
            }
        }

        // ---------- Phone-control channel ----------
        MethodChannel(messenger, "sonic/assistant").setMethodCallHandler { call, result ->
            val svc = AssistantAccessibilityService.instance
            if (svc == null) {
                result.error("NO_SERVICE", "Accessibility service on nahi hai", null); return@setMethodCallHandler
            }
            when (call.method) {
                "openApp" -> result.success(svc.openApp(call.argument<String>("package") ?: ""))
                "tap" -> result.success(svc.tap((call.argument<Double>("x") ?: 0.0).toFloat(), (call.argument<Double>("y") ?: 0.0).toFloat()))
                "type" -> result.success(svc.type(call.argument<String>("text") ?: ""))
                "readScreen" -> result.success(svc.readScreen())
                "call" -> result.success(svc.call(call.argument<String>("number") ?: ""))
                "sms" -> result.success(svc.sms(call.argument<String>("number") ?: "", call.argument<String>("text") ?: ""))
                "showStop" -> { svc.showStopButton(); result.success(true) }
                "hideStop" -> { svc.hideStopButton(); result.success(true) }
                else -> result.notImplemented()
            }
        }
    }

    /** Copies the installed APK to Downloads/Sonic-v1.apk and returns the path. */
    private fun copyApkToDownload(): String {
        val src = File(applicationInfo.sourceDir)
        val name = "Sonic-v1.apk"
        val target = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), name)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val resolver = contentResolver
            // Remove older copy so we don't get "Sonic-v1 (1).apk"
            resolver.delete(MediaStore.Downloads.EXTERNAL_CONTENT_URI, "${MediaStore.Downloads.DISPLAY_NAME}=?", arrayOf(name))
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name)
                put(MediaStore.Downloads.MIME_TYPE, "application/vnd.android.package-archive")
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            }
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("Download mein file nahi ban saki")
            resolver.openOutputStream(uri)!!.use { out -> src.inputStream().use { it.copyTo(out) } }
        } else {
            target.parentFile?.mkdirs()
            src.copyTo(target, overwrite = true)
        }
        return target.absolutePath
    }

    private fun installApk(path: String) {
        var file = File(path)
        if (!file.exists() || !file.canRead()) {
            // Fallback: copy into app cache (covered by <cache-path> in file_paths.xml)
            file = File(cacheDir, "Sonic-v1.apk")
            File(applicationInfo.sourceDir).copyTo(file, overwrite = true)
        }
        val uri: Uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        startActivity(intent)
    }
}
